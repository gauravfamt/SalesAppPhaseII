class InvoiceStatus {
  String key;
  String value;
  int index;
  InvoiceStatus({this.key, this.value, this.index});
}
