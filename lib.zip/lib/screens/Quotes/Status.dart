class QuoteStatus {
  String key;
  String value;
  int index;
  QuoteStatus({this.key, this.value, this.index});
}
