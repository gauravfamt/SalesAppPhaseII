class OrderDeliveryStatus {
  String key;
  String value;
  int index;
  OrderDeliveryStatus({this.key, this.value, this.index});
}
