export 'InventoryScreen.dart';
